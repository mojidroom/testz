# ساخت APK آماده با GitHub Actions (بدون نصب Android Studio)

این پروژه یک workflow آماده دارد که APK را روی سرور GitHub می‌سازد.

1. وارد https://github.com شو و یک حساب رایگان بساز/وارد شو.
2. از علامت + بالا گزینه **New repository** را بزن.
3. نامی مثل `ZohoIntentProbe` انتخاب کن، روی **Private** بگذار و **Create repository** را بزن.
4. در صفحه مخزن، **Add file → Upload files** را بزن.
5. فایل‌های داخل پوشه `ZohoIntentProbe` را (نه خود پوشه‌ی بیرونی) انتخاب و بکش داخل صفحه؛ حتماً پوشه‌ی مخفی `.github` هم آپلود شود. سپس **Commit changes** را بزن.
6. از تب **Actions**، workflow با نام **Build Android APK** را باز کن.
7. روی **Run workflow** و سپس دکمه سبز **Run workflow** بزن.
8. پس از تمام‌شدن اجرا با علامت سبز، وارد همان اجرای workflow شو و پایین صفحه از بخش **Artifacts** فایل `ZohoIntentProbe-debug-apk` را دانلود کن.
9. ZIP دانلودشده را باز کن؛ فایل `app-debug.apk` داخل آن است. آن را به گوشی منتقل و نصب کن.

اگر GitHub پیام داد Actions غیرفعال است، در تب Actions آن را برای مخزن فعال کن. مخزن را Private نگه دار؛ پروژه هیچ کلید یا اطلاعات حسابی لازم ندارد.
